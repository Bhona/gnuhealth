GNU Health Inpatient calendar Module
####################################

This module add support to:

     * Link beds with calendars

     * Create calendar events from inpatient registrations
