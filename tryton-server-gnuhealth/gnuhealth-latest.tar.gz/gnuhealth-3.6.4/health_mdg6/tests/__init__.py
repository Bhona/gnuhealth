from .test_health_mdg6 import suite
