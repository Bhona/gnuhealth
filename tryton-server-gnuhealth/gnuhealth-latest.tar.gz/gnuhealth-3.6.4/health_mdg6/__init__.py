# -*- coding: utf-8 -*-
from .health_mdg6 import *
