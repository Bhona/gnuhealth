class immunizationRoute:
    contents=[{'code': 'IM',
                'display': 'Intramuscular'},
            {'code': 'PO',
                'display': 'Oral'},
            {'code': 'NAS',
                'display': 'Intranasal'},
            {'code': 'SC',
                'display': 'Subcutaneous'},
            {'code': 'ID',
                'display': 'Intradermal'}]

__all__=['immunizationRoute']
