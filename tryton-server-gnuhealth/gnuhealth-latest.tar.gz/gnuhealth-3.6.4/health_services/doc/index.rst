GNU Health Services and orders Module
#####################################

This module allows grouping the services and orders related to a patient
evaluation / encounter and or Hospitalization.

It also permits invoicing the selected orders.


