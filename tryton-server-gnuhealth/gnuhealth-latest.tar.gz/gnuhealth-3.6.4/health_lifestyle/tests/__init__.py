from .test_health_lifestyle import suite
