GNU Health Lab Services and orders Module
##########################################

This module allows grouping the services and orders related to a patient

It adds the funtionality for Lab orders to the health_service module

It also permits invoicing the selected orders.


