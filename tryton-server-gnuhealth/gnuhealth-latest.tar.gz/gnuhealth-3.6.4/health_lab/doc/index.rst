GNU Health Laboratory Module
############################

This modules includes lab tests: Values, reports and PoS.
